package com.proftelran.org.lessontwo;

public class BigCat extends Cat {

    private int height;

    public BigCat(int age) {
        super(age);
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
